import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { HeartHandshake, Menu, X } from "lucide-react";

const nav = [
  { to: "/", label: "Home" },
  { to: "/understanding", label: "Understanding" },
  { to: "/survey", label: "Take the check-in" },
  { to: "/find-help", label: "Find support" },
  { to: "/privacy", label: "Privacy" },
] as const;

export function SiteShell({ children }: { children: ReactNode }) {
  const { location } = useRouterState();
  const [open, setOpen] = useState(false);
  const [signedIn, setSignedIn] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSignedIn(!!data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSignedIn(!!s));
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur-md">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-primary/15 text-primary">
              <HeartHandshake className="h-5 w-5" />
            </span>
            <span className="font-display text-lg tracking-tight">Solace</span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                className={`px-3 py-2 rounded-full text-sm transition-colors ${
                  location.pathname === n.to
                    ? "bg-primary/15 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                {n.label}
              </Link>
            ))}
            {signedIn ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => supabase.auth.signOut()}
                className="ml-2"
              >
                Sign out
              </Button>
            ) : (
              <Link to="/auth" className="ml-2">
                <Button size="sm" variant="secondary">Sign in</Button>
              </Link>
            )}
          </nav>
          <button
            className="md:hidden p-2 rounded-md hover:bg-muted"
            aria-label="Toggle menu"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
        {open && (
          <div className="md:hidden border-t border-border/60 bg-background/95">
            <div className="mx-auto max-w-6xl px-4 py-3 flex flex-col gap-1">
              {nav.map((n) => (
                <Link
                  key={n.to}
                  to={n.to}
                  onClick={() => setOpen(false)}
                  className={`px-3 py-2 rounded-md text-sm ${
                    location.pathname === n.to ? "bg-primary/15 text-primary" : "hover:bg-muted"
                  }`}
                >
                  {n.label}
                </Link>
              ))}
              {signedIn ? (
                <Button variant="ghost" onClick={() => supabase.auth.signOut()}>Sign out</Button>
              ) : (
                <Link to="/auth" onClick={() => setOpen(false)}>
                  <Button size="sm" variant="secondary" className="w-full">Sign in</Button>
                </Link>
              )}
            </div>
          </div>
        )}
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-border/60 bg-muted/40">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-8 text-sm text-muted-foreground flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
          <p>
            Solace is a reflective wellbeing tool for students. It is <strong>not</strong> a diagnostic or medical service.
          </p>
          <p className="text-xs">
            © {new Date().getFullYear()} Solace ·{" "}
            <a href="/privacy" className="underline hover:text-foreground">Privacy & Data Safety</a>
            {" · "}Your responses are never stored.
          </p>
        </div>
      </footer>
    </div>
  );
}
