// Minimal helper that calls Lovable AI Gateway (OpenAI-compatible) directly.
// Kept dependency-free — no AI SDK install required.

export interface ChatMessage { role: "system" | "user" | "assistant"; content: string }

export async function generateReport(messages: ChatMessage[]): Promise<string> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${key}`,
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages,
      temperature: 0.6,
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    if (res.status === 429) throw new Error("The reflection engine is busy. Please try again in a moment.");
    if (res.status === 402) throw new Error("AI credits are exhausted. Please contact the site owner.");
    throw new Error(`AI request failed (${res.status}): ${body.slice(0, 200)}`);
  }

  const data = await res.json();
  const text: string | undefined = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error("Empty AI response");
  return text;
}
