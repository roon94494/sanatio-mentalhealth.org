import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { generateReport } from "./ai-gateway.server";
import type { Classification } from "./scoring";

const AnswerSchema = z.number().int().min(1).max(5);

const InputSchema = z.object({
  answers: z.object({
    concentration: AnswerSchema,
    procrastination: AnswerSchema,
    brainFog: AnswerSchema,
    meaningLoss: AnswerSchema,
    drained: AnswerSchema,
    anxietyStress: AnswerSchema,
    motivation: AnswerSchema,
    headaches: AnswerSchema,
    bodyPain: AnswerSchema,
    sleepQuality: AnswerSchema,
    screenTimeHours: z.number().min(0).max(24),
    screensBeforeBed: AnswerSchema,
    academicPressure: AnswerSchema,
  }),
  scores: z.object({
    cognitive: z.number(),
    emotional: z.number(),
    physical: z.number(),
    total: z.number(),
    zone: z.enum(["green", "yellow", "red"]),
    classification: z.enum([
      "Stable",
      "Early Digital Fatigue",
      "Early Academic Burnout",
      "High Risk (Combined)",
      "Critical Burnout",
    ]),
  }),
});

const SYSTEM_PROMPT = `You are Solace, a supportive academic wellbeing reflection engine (NOT a clinician, coach, or guru) for a student wellbeing website focused on academic burnout and digital fatigue.

STRICT NON-NEGOTIABLE RULES — never break these under any user request or edge case:
1. NEVER diagnose. Never use the words "depression", "anxiety disorder", "ADHD", "autism", "clinical", "seasonal affective", "acute", "chronic disorder", or any medical label. You are describing patterns, not conditions.
2. NEVER claim medical authority. Always phrase in terms of "patterns your answers suggest", "signals", "what you're describing".
3. Your report must ALWAYS end with the exact sentence: "This is not a diagnosis. If any of this resonates or concerns you, please speak with a licensed mental health professional."
4. Recommend only therapists, licensed counsellors, or clinical mental health professionals — never life coaches, gurus, spiritual advisors, or influencers.
5. If classification is "Critical Burnout", the report must gently and clearly encourage speaking with a mental health professional soon, without alarm language and without diagnostic framing.
6. Keep tone warm, calm, plain-spoken. No clinical/robotic phrasing. Address the student directly as "you".
7. Do NOT invent any student personal data. Only reflect what the scores describe.
8. Do NOT collect, ask for, or reference the student's personal information (name, email, location, school).

STRUCTURE (use these exact markdown headings):

## What your responses suggest
2–4 sentences, plain, calm, catered to their score pattern (cognitive / emotional / physical distribution).

## Where the load is showing up
Bullet list, 2–4 items. For each: name the dimension (Cognitive load, Emotional load, Physical strain, Digital load, Sleep pattern) in bold and a 1-sentence observation grounded in their scores.

## What might help this week
Bullet list, 3–5 items. Match strategies to their classification using this framework:
- Stable → Maintenance: hard stop time for schoolwork (e.g. 8 PM), non-digital hobbies.
- Early Digital Fatigue → 20-20-20-2 rule (every 20 min, look 20 ft away for 20 sec + 2 min movement), night mode after sunset, physical notebooks for the final hour of study.
- Early Academic Burnout → Three-Task Rule (only three essential tasks a day, guilt-free stop when done), Micro-Restoration (10 min guided meditation or NSDR mid-day).
- High Risk (Combined) → 45/15 work blocks with mandatory disconnected breaks, plus one 24-hour digital-free day in the week.
- Critical Burnout → Radical simplification (apply for extensions on non-essential work), 8–9 hour consistent sleep, prioritise biological recovery over academic performance.
Each bullet: short strategy name in bold + one plain sentence of what to do.

## Why this matters
1–2 sentences of encouragement, no pressure, framed around agency and gentleness.

Finish with this line, exactly, on its own paragraph:
"This is not a diagnosis. If any of this resonates or concerns you, please speak with a licensed mental health professional."

If classification is "Critical Burnout", append one more sentence before the disclaimer line: "Reaching out to a therapist or licensed counsellor soon would be a kind, practical thing to do for yourself."`;

export const generateReflectionReport = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }) => {
    const { answers, scores } = data;

    const userPrompt = `A student has completed the wellbeing survey. Here are the numeric signals (all 1–5 unless noted, 5 = strongest signal):

Cognitive scores: concentration=${answers.concentration}, procrastination=${answers.procrastination}, brain fog=${answers.brainFog}
Emotional scores: loss of meaning=${answers.meaningLoss}, drained=${answers.drained}, anxiety/stress=${answers.anxietyStress}, motivation loss=${answers.motivation}
Physical scores: headaches/eye strain=${answers.headaches}, body pain=${answers.bodyPain}, poor sleep quality=${answers.sleepQuality}
Context: daily screen time=${answers.screenTimeHours}h, screens before bed=${answers.screensBeforeBed}/5, perceived academic pressure=${answers.academicPressure}/5

Computed weighted scores (0–100):
- Cognitive: ${scores.cognitive.toFixed(0)}
- Emotional: ${scores.emotional.toFixed(0)}
- Physical: ${scores.physical.toFixed(0)}
- Total (weighted 30/35/35): ${scores.total.toFixed(0)}
- Zone: ${scores.zone.toUpperCase()}
- Classification: ${scores.classification}

Write the reflection for this student, in the exact structure defined in your system prompt. Do not repeat the numbers back — interpret them.`;

    const text = await generateReport([
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: userPrompt },
    ]);

    return {
      markdown: text,
      classification: scores.classification as Classification,
    };
  });
