// Weighted Scoring Engine — client-safe.
// Weights: Cognitive 30%, Emotional 35%, Physical 35%.
// Result classification follows the case study's decision table + threshold logic.

export type Answer = 1 | 2 | 3 | 4 | 5;

export interface SurveyAnswers {
  // Cognitive (30%)
  concentration: Answer;       // How often do you struggle to concentrate? (1 rarely – 5 constantly)
  procrastination: Answer;     // How often do you procrastinate essential tasks?
  brainFog: Answer;            // Forgetfulness / brain fog frequency
  // Emotional (35%)
  meaningLoss: Answer;         // Studies losing their meaning?
  drained: Answer;             // How often mentally drained?
  anxietyStress: Answer;       // Feel anxious/stressed about school?
  motivation: Answer;          // Loss of motivation? (5 = severe loss)
  // Physical (35%)
  headaches: Answer;           // Frequency of headaches / eye strain
  bodyPain: Answer;            // Neck/back/muscle pain after study
  sleepQuality: Answer;        // Poor sleep quality? (5 = very poor)
  // Contextual (used for classification triggers, not weighted score)
  screenTimeHours: number;     // avg daily hours
  screensBeforeBed: Answer;    // 1 never – 5 every night
  academicPressure: Answer;    // perceived pressure
}

export interface ScoreBreakdown {
  cognitive: number;   // 0–100
  emotional: number;   // 0–100
  physical: number;    // 0–100
  total: number;       // 0–100 weighted
  zone: "green" | "yellow" | "red";
  classification: Classification;
}

export type Classification =
  | "Stable"
  | "Early Digital Fatigue"
  | "Early Academic Burnout"
  | "High Risk (Combined)"
  | "Critical Burnout";

// Normalize a 1–5 scale into 0–100
const norm = (v: Answer) => ((v - 1) / 4) * 100;
const avg = (nums: number[]) => nums.reduce((a, b) => a + b, 0) / nums.length;

export function computeScore(a: SurveyAnswers): ScoreBreakdown {
  const cognitive = avg([norm(a.concentration), norm(a.procrastination), norm(a.brainFog)]);
  const emotional = avg([norm(a.meaningLoss), norm(a.drained), norm(a.anxietyStress), norm(a.motivation)]);
  const physical  = avg([norm(a.headaches), norm(a.bodyPain), norm(a.sleepQuality)]);

  const total = cognitive * 0.30 + emotional * 0.35 + physical * 0.35;

  const zone: ScoreBreakdown["zone"] = total <= 40 ? "green" : total <= 70 ? "yellow" : "red";
  const classification = classify(a, total);

  return { cognitive, emotional, physical, total, zone, classification };
}

function classify(a: SurveyAnswers, total: number): Classification {
  const highScreen = a.screenTimeHours > 8;
  const midScreen = a.screenTimeHours > 6;
  const heavyPhysical = a.headaches >= 4 || a.bodyPain >= 4;
  const severeEmotional = a.drained >= 4 && a.motivation >= 4 && a.anxietyStress >= 4;
  const extremePressure = a.academicPressure >= 5;

  if (total >= 85 && extremePressure && highScreen && heavyPhysical && severeEmotional) {
    return "Critical Burnout";
  }
  if (total > 70) return "High Risk (Combined)";
  if (total > 55 && a.academicPressure >= 4 && midScreen) return "Early Academic Burnout";
  if (total >= 40 && (a.headaches >= 3 || a.screensBeforeBed >= 4)) return "Early Digital Fatigue";
  return "Stable";
}

export const classificationCopy: Record<Classification, { headline: string; summary: string }> = {
  "Stable": {
    headline: "You're holding steady.",
    summary: "Your responses suggest a balanced academic rhythm right now. The goal is to protect this state.",
  },
  "Early Digital Fatigue": {
    headline: "Your screens may be quietly wearing you down.",
    summary: "Physiological signs of digital strain are showing up before the emotional load has fully arrived.",
  },
  "Early Academic Burnout": {
    headline: "The workload is starting to feel heavier than it should.",
    summary: "Cynicism, detachment, or a sense of being 'over it' are early emotional signals — not a verdict.",
  },
  "High Risk (Combined)": {
    headline: "Two waves are hitting at once.",
    summary: "Both digital and academic exhaustion are compounding. Short structured recovery is the priority.",
  },
  "Critical Burnout": {
    headline: "This deserves gentle, immediate attention.",
    summary: "Your signals point to a state where recovery — not more effort — is the safest next step. This is not a diagnosis.",
  },
};
