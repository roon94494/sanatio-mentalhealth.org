import type { SurveyAnswers, Answer } from "./scoring";

export type QuestionKey = keyof SurveyAnswers;

export interface Question {
  key: QuestionKey;
  section: "Cognitive" | "Emotional" | "Physical" | "Context";
  prompt: string;
  scale: [string, string]; // labels for 1 and 5
  kind: "likert" | "hours";
}

export const questions: Question[] = [
  { key: "concentration", section: "Cognitive", prompt: "How often do you struggle to concentrate on specific tasks?", scale: ["Rarely", "Constantly"], kind: "likert" },
  { key: "procrastination", section: "Cognitive", prompt: "How often do you put off essential schoolwork even when you have the time?", scale: ["Rarely", "Always"], kind: "likert" },
  { key: "brainFog", section: "Cognitive", prompt: "How often do you feel forgetful or mentally foggy during study?", scale: ["Rarely", "All the time"], kind: "likert" },
  { key: "meaningLoss", section: "Emotional", prompt: "Do you feel your studies are losing their meaning?", scale: ["Not at all", "Completely"], kind: "likert" },
  { key: "drained", section: "Emotional", prompt: "How mentally drained do you feel across a typical week?", scale: ["Fresh", "Fully drained"], kind: "likert" },
  { key: "anxietyStress", section: "Emotional", prompt: "How often do you feel anxious, stressed or troubled about school?", scale: ["Rarely", "Constantly"], kind: "likert" },
  { key: "motivation", section: "Emotional", prompt: "Have you lost motivation for things you used to care about?", scale: ["Still motivated", "Fully unmotivated"], kind: "likert" },
  { key: "headaches", section: "Physical", prompt: "How often do you get headaches or eye strain after screen study sessions?", scale: ["Rarely", "Every day"], kind: "likert" },
  { key: "bodyPain", section: "Physical", prompt: "Do you experience neck, back or muscle pain after long study sessions?", scale: ["Never", "Always"], kind: "likert" },
  { key: "sleepQuality", section: "Physical", prompt: "How would you rate your sleep quality lately?", scale: ["Restorative", "Very poor"], kind: "likert" },
  { key: "academicPressure", section: "Context", prompt: "How much academic pressure do you feel overall?", scale: ["Low", "Extreme"], kind: "likert" },
  { key: "screensBeforeBed", section: "Context", prompt: "How often do you use screens right before going to sleep?", scale: ["Never", "Every night"], kind: "likert" },
  { key: "screenTimeHours", section: "Context", prompt: "On an average day, roughly how many hours do you spend on screens?", scale: ["", ""], kind: "hours" },
];

export const defaultAnswers: SurveyAnswers = {
  concentration: 3, procrastination: 3, brainFog: 3,
  meaningLoss: 3, drained: 3, anxietyStress: 3, motivation: 3,
  headaches: 3, bodyPain: 3, sleepQuality: 3,
  screenTimeHours: 6, screensBeforeBed: 3, academicPressure: 3,
};

export type { Answer };
