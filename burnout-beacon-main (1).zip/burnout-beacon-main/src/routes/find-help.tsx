import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Phone, Mail, Globe } from "lucide-react";

export const Route = createFileRoute("/find-help")({
  head: () => ({
    meta: [
      { title: "Find a mental health professional — Solace" },
      { name: "description", content: "Directories and hotlines to reach a licensed therapist, counsellor, or crisis service — locally and online." },
    ],
  }),
  component: FindHelp,
});

// Curated: internationally-recognised directories/hotlines. Prioritises licensed professionals.
const directories = [
  {
    region: "International directories (find a therapist)",
    items: [
      { name: "Psychology Today — Find a Therapist", detail: "Search licensed therapists by location, specialty and insurance.", href: "https://www.psychologytoday.com/us/therapists", icon: Globe },
      { name: "International Therapist Directory", detail: "Global directory focused on licensed clinicians.", href: "https://internationaltherapistdirectory.com/", icon: Globe },
      { name: "BetterHelp (remote licensed therapists)", detail: "Video/phone/chat sessions with licensed therapists.", href: "https://www.betterhelp.com/", icon: Globe },
    ],
  },
  {
    region: "Crisis lines (24/7)",
    items: [
      { name: "988 Suicide & Crisis Lifeline (US)", detail: "Call or text 988.", href: "tel:988", icon: Phone },
      { name: "Samaritans (UK & Ireland)", detail: "Call 116 123, free, 24/7.", href: "tel:116123", icon: Phone },
      { name: "Find A Helpline (global)", detail: "Verified crisis support in 130+ countries.", href: "https://findahelpline.com/", icon: Globe },
    ],
  },
];

function FindHelp() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <h1 className="font-display text-4xl">Finding someone to talk to</h1>
      <p className="mt-4 text-muted-foreground leading-relaxed">
        The people worth talking to about how you're feeling are <strong>licensed mental health professionals</strong> —
        therapists, psychologists, counsellors, clinical social workers. Not life coaches. Not gurus. Not influencers.
        Below are trusted directories and crisis lines. Reaching out is not weakness — it's care, done well.
      </p>

      {directories.map((group) => (
        <section key={group.region} className="mt-10">
          <h2 className="font-display text-2xl">{group.region}</h2>
          <div className="mt-4 grid gap-3">
            {group.items.map((item) => (
              <a
                key={item.name}
                href={item.href}
                target={item.href.startsWith("http") ? "_blank" : undefined}
                rel={item.href.startsWith("http") ? "noopener noreferrer" : undefined}
                className="soft-card p-5 flex items-start gap-4 hover:border-primary/40 transition-colors"
              >
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary shrink-0">
                  <item.icon className="h-5 w-5" />
                </span>
                <div className="min-w-0">
                  <h3 className="font-medium">{item.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.detail}</p>
                </div>
              </a>
            ))}
          </div>
        </section>
      ))}

      <div className="mt-10 rounded-2xl border border-border p-6 bg-secondary/40">
        <h2 className="font-display text-xl">Prefer to speak to your school counsellor?</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Many schools and universities offer free, confidential counselling. Check with your student services
          office — they can also refer you to community clinics if needed.
        </p>
      </div>

      <p className="mt-10 text-xs text-muted-foreground">
        Solace is not affiliated with any of the services above and cannot diagnose or treat any condition.
      </p>
    </div>
  );
}
