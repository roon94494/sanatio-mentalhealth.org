import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, ShieldCheck, HeartPulse } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Solace — A calm check-in for student burnout & digital fatigue" },
      { name: "description", content: "Notice how you're really doing. Solace is a private, non-diagnostic reflection tool that helps students spot early signs of academic burnout and digital fatigue." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div>
      {/* Hero with animated pastel background — landing page ONLY */}
      <section className="relative overflow-hidden">
        <div className="calm-bg" aria-hidden>
          <div className="calm-bg-orb" />
        </div>
        <div className="relative z-10 mx-auto max-w-4xl px-4 sm:px-6 pt-20 pb-24 md:pt-28 md:pb-32 text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-background/70 px-3 py-1 text-xs text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5" /> A quiet space for students
          </span>
          <h1 className="mt-6 font-display text-4xl md:text-6xl leading-tight">
            When was the last time <br className="hidden sm:block"/>
            <span className="text-primary">you asked yourself how you're doing?</span>
          </h1>
          <p className="mt-6 mx-auto max-w-2xl text-base md:text-lg text-muted-foreground">
            Between assignments, deadlines, screens and expectations, exhaustion often arrives before we
            notice it's there. Solace is a gentle, private check-in that helps you spot the early patterns —
            before you crash.
          </p>
          <div className="mt-8 flex flex-wrap gap-3 justify-center">
            <Link to="/survey">
              <Button size="lg" className="rounded-full">
                Take the check-in <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link to="/understanding">
              <Button size="lg" variant="secondary" className="rounded-full">
                Learn what's going on
              </Button>
            </Link>
          </div>
          <p className="mt-6 text-xs text-muted-foreground">
            No personal data is stored. Sign-in is only asked when you begin the survey, so we can deliver your reflection back to you.
          </p>
        </div>
      </section>

      {/* Value cards */}
      <section className="mx-auto max-w-5xl px-4 sm:px-6 py-16 grid gap-4 md:grid-cols-3">
        {[
          {
            icon: HeartPulse,
            title: "Notice patterns early",
            body: "Sleep, screen time, motivation, focus — small signals matter. Solace listens to them before they compound.",
          },
          {
            icon: Sparkles,
            title: "A reflection made for you",
            body: "Your answers are read through multiple perspectives, not a one-size checklist, so what you get back actually fits your situation.",
          },
          {
            icon: ShieldCheck,
            title: "Yours, and yours alone",
            body: "No storage of your responses, no tracking, no marketing emails. The only place your reflection goes is to you.",
          },
        ].map((c) => (
          <div key={c.title} className="soft-card p-6">
            <div className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-accent/50 text-accent-foreground">
              <c.icon className="h-5 w-5" />
            </div>
            <h3 className="mt-4 font-display text-xl">{c.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{c.body}</p>
          </div>
        ))}
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-4xl px-4 sm:px-6 py-16">
        <h2 className="font-display text-3xl md:text-4xl text-center">How your check-in works</h2>
        <ol className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            { n: "01", t: "Answer honestly", d: "A short set of questions about how your mind, body and screens have felt lately." },
            { n: "02", t: "We reflect it back", d: "A gentle, personal summary — not a label — highlighting what your answers seem to describe." },
            { n: "03", t: "Small, doable steps", d: "Concrete strategies matched to your pattern. Never a diagnosis. Always your call." },
          ].map((s) => (
            <li key={s.n} className="soft-card p-6">
              <span className="font-display text-primary text-xl">{s.n}</span>
              <h3 className="mt-2 font-display text-lg">{s.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
            </li>
          ))}
        </ol>
        <div className="mt-10 text-center">
          <Link to="/survey">
            <Button size="lg" className="rounded-full">Begin your check-in</Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
