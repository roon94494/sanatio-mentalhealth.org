import { createFileRoute } from "@tanstack/react-router";
import { Shield, Lock, EyeOff, Trash2, Mail, FileText } from "lucide-react";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy & Data Safety — Solace" },
      { name: "description", content: "How Solace handles your check-in answers: session-only storage, no personal data retention, and no marketing emails." },
      { property: "og:title", content: "Privacy & Data Safety — Solace" },
      { property: "og:description", content: "Your answers stay in this browser session. We do not store personal data, send marketing emails, or share your responses." },
    ],
  }),
  component: PrivacyPage,
});

const sections = [
  {
    icon: EyeOff,
    title: "Your answers stay on your device",
    body: "When you take the Solace check-in, your responses are held temporarily in your browser's sessionStorage. They are not uploaded to a database, not linked to your profile, and not kept after you close the tab. We literally cannot read them back later — because we never saved them.",
  },
  {
    icon: Lock,
    title: "Authentication is only for delivery",
    body: "We ask you to sign in before the survey so your personal reflection can be sent to your registered email. That is the only reason authentication exists. We do not use your sign-in status to track you, build a profile, or target you with content.",
  },
  {
    icon: Trash2,
    title: "Nothing is retained after the report",
    body: "Once your reflection is generated and emailed, the survey answers and scores are cleared from sessionStorage. There is no archive of responses, no analytics spreadsheet, and no long-term record of how you answered.",
  },
  {
    icon: Mail,
    title: "One email, one purpose",
    body: "The only email you will receive is the reflection report you requested. We do not send follow-ups, marketing campaigns, diagnosis reminders, or nudges to see a doctor. If you ever receive anything else claiming to be from Solace, please treat it with caution and contact us through the site.",
  },
  {
    icon: Shield,
    title: "No diagnosis, no medical advice",
    body: "Solace is a reflective wellbeing tool, not a clinical or diagnostic service. The report you receive is a gentle, non-medical reflection based on the patterns you described. It will always encourage speaking with a qualified mental health professional if you have concerns — but it will never label you with a condition.",
  },
  {
    icon: FileText,
    title: "This page is maintained by Solace",
    body: "The practices described here reflect how this app is built today. If anything changes, this page will be updated first. If you have questions about how your data is handled, reach out through the contact channels listed on the site.",
  },
];

function PrivacyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12 md:py-20">
      <header className="text-center mb-12">
        <span className="inline-flex items-center gap-2 rounded-full border border-border bg-background/70 px-3 py-1 text-xs text-muted-foreground">
          <Shield className="h-3.5 w-3.5" /> Your data, your rules
        </span>
        <h1 className="mt-5 font-display text-3xl md:text-5xl leading-tight">
          Privacy & Data Safety
        </h1>
        <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
          Solace was designed so that you can be honest without worrying about where your answers end up. Here is exactly what happens — and does not happen — with your information.
        </p>
      </header>

      <div className="grid gap-6 md:grid-cols-2">
        {sections.map((s) => (
          <div key={s.title} className="soft-card p-6">
            <div className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
              <s.icon className="h-5 w-5" />
            </div>
            <h2 className="mt-4 font-display text-xl">{s.title}</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.body}</p>
          </div>
        ))}
      </div>

      <div className="mt-12 soft-card p-6 md:p-8 bg-secondary/20 border-secondary/30">
        <h2 className="font-display text-2xl">Quick promise</h2>
        <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
          <li className="flex gap-3">
            <span className="text-primary">✓</span>
            <span>Your answers live only in your current browser session.</span>
          </li>
          <li className="flex gap-3">
            <span className="text-primary">✓</span>
            <span>We do not store personal data, responses, or scores on our servers.</span>
          </li>
          <li className="flex gap-3">
            <span className="text-primary">✓</span>
            <span>We do not sell, share, or use your information for marketing.</span>
          </li>
          <li className="flex gap-3">
            <span className="text-primary">✓</span>
            <span>The only email we send is the reflection report you asked for.</span>
          </li>
          <li className="flex gap-3">
            <span className="text-primary">✓</span>
            <span>Solace is not a diagnostic tool and never will be.</span>
          </li>
        </ul>
      </div>

      <p className="mt-10 text-center text-xs text-muted-foreground">
        Last updated: {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
      </p>
    </div>
  );
}
