import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { generateReflectionReport } from "@/lib/report.functions";
import { computeScore, classificationCopy, type SurveyAnswers, type ScoreBreakdown } from "@/lib/scoring";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from "recharts";
import { AlertTriangle, LifeBuoy } from "lucide-react";

export const Route = createFileRoute("/report")({
  head: () => ({
    meta: [
      { title: "Your reflection — Solace" },
      { name: "description", content: "A personal, non-diagnostic reflection based on your Solace check-in." },
    ],
  }),
  component: ReportPage,
});

function ReportPage() {
  const navigate = useNavigate();
  const runReport = useServerFn(generateReflectionReport);
  const [answers, setAnswers] = useState<SurveyAnswers | null>(null);
  const [scores, setScores] = useState<ScoreBreakdown | null>(null);
  const [markdown, setMarkdown] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) {
        navigate({ to: "/auth", search: { next: "/report" } });
        return;
      }
      const rawA = sessionStorage.getItem("solace:answers");
      const rawS = sessionStorage.getItem("solace:scores");
      if (!rawA || !rawS) {
        navigate({ to: "/survey" });
        return;
      }
      const a = JSON.parse(rawA) as SurveyAnswers;
      const s = computeScore(a); // recompute for integrity
      setAnswers(a);
      setScores(s);

      runReport({ data: { answers: a, scores: s } })
        .then((r) => setMarkdown(r.markdown))
        .catch((e) => setError(e instanceof Error ? e.message : "Couldn't generate reflection."))
        .finally(() => setLoading(false));
    });
  }, [navigate, runReport]);

  if (!scores || !answers) {
    return <div className="mx-auto max-w-2xl px-4 py-24 text-center text-muted-foreground">Preparing your reflection…</div>;
  }

  const copy = classificationCopy[scores.classification];
  const isCritical = scores.classification === "Critical Burnout";

  const chartData = [
    { name: "Cognitive", value: Math.round(scores.cognitive) },
    { name: "Emotional", value: Math.round(scores.emotional) },
    { name: "Physical", value: Math.round(scores.physical) },
    { name: "Overall", value: Math.round(scores.total) },
  ];

  const barColor = scores.zone === "green"
    ? "var(--zone-green)"
    : scores.zone === "yellow"
      ? "var(--zone-yellow)"
      : "var(--zone-red)";

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <div className="soft-card p-6 md:p-10">
        <p className="text-xs uppercase tracking-wider text-primary font-medium">Your reflection</p>
        <h1 className="mt-3 font-display text-3xl md:text-4xl">{copy.headline}</h1>
        <p className="mt-3 text-muted-foreground leading-relaxed">{copy.summary}</p>

        {/* Chart */}
        <div className="mt-8">
          <h2 className="font-display text-lg mb-3">Where the load sits</h2>
          <div className="h-56 w-full">
            <ResponsiveContainer>
              <BarChart data={chartData} layout="vertical" margin={{ left: 8, right: 24 }}>
                <XAxis type="number" domain={[0, 100]} hide />
                <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} width={80} />
                <Tooltip
                  formatter={(v: number) => `${v} / 100`}
                  contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", background: "var(--card)" }}
                />
                <Bar dataKey="value" radius={[8, 8, 8, 8]}>
                  {chartData.map((_, i) => <Cell key={i} fill={barColor} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-2 text-xs mt-2 text-muted-foreground">
            <ZoneBadge active={scores.zone === "green"} color="var(--zone-green)" label="Green (0–40)" />
            <ZoneBadge active={scores.zone === "yellow"} color="var(--zone-yellow)" label="Yellow (41–70)" />
            <ZoneBadge active={scores.zone === "red"} color="var(--zone-red)" label="Red (71–100)" />
          </div>
        </div>

        {/* Narrative */}
        <div className="mt-10 prose-solace">
          {loading && <p className="text-muted-foreground">Reflecting on your answers…</p>}
          {error && <p className="text-destructive text-sm">{error}</p>}
          {!loading && !error && <RenderMarkdown source={markdown} />}
        </div>

        {/* Critical Burnout — dedicated action */}
        {isCritical && !loading && (
          <div className="mt-8 rounded-2xl border border-destructive/40 bg-destructive/5 p-5">
            <div className="flex gap-3 items-start">
              <AlertTriangle className="h-5 w-5 mt-0.5 text-destructive" />
              <div>
                <h3 className="font-display text-lg">Talking to a professional is a kind next step</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Reaching out to a licensed therapist or counsellor near you — remote or in person — can help
                  you steady things. Not a life coach, not a guru, a trained mental health professional.
                </p>
                <div className="mt-4">
                  <Link to="/find-help">
                    <Button className="rounded-full" variant="destructive">
                      <LifeBuoy className="mr-2 h-4 w-4" /> Connect with a professional
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}

        {!isCritical && !loading && (
          <div className="mt-8 text-sm text-muted-foreground border-t border-border pt-6">
            If any of this resonates and you'd like to speak with someone,{" "}
            <Link to="/find-help" className="text-primary underline underline-offset-4">
              find a mental health professional near you
            </Link>.
          </div>
        )}
      </div>

      <div className="mt-6 flex flex-wrap gap-2 justify-center">
        <Link to="/survey"><Button variant="secondary" className="rounded-full">Retake the check-in</Button></Link>
        <Link to="/"><Button variant="ghost" className="rounded-full">Back to home</Button></Link>
      </div>
    </div>
  );
}

function ZoneBadge({ active, color, label }: { active: boolean; color: string; label: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 ${active ? "border-foreground/30 bg-background" : "border-border/60 opacity-60"}`}>
      <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: color }} />
      {label}
    </span>
  );
}

/** Extremely small, safe markdown renderer for our known structure (## headings, - bullets, **bold**, paragraphs). */
function RenderMarkdown({ source }: { source: string }) {
  const lines = source.split(/\r?\n/);
  const nodes: React.ReactNode[] = [];
  let listBuffer: string[] = [];
  const flushList = () => {
    if (listBuffer.length) {
      nodes.push(
        <ul key={`ul-${nodes.length}`} className="my-3 space-y-2 list-disc pl-5">
          {listBuffer.map((li, i) => <li key={i}><Inline text={li} /></li>)}
        </ul>
      );
      listBuffer = [];
    }
  };
  lines.forEach((raw, idx) => {
    const line = raw.trim();
    if (line.startsWith("## ")) {
      flushList();
      nodes.push(<h2 key={`h-${idx}`} className="font-display text-xl mt-6 mb-2">{line.slice(3)}</h2>);
    } else if (line.startsWith("- ") || line.startsWith("* ")) {
      listBuffer.push(line.slice(2));
    } else if (line.length === 0) {
      flushList();
    } else {
      flushList();
      nodes.push(<p key={`p-${idx}`} className="my-2 text-muted-foreground leading-relaxed"><Inline text={line} /></p>);
    }
  });
  flushList();
  return <>{nodes}</>;
}

function Inline({ text }: { text: string }) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return (
    <>
      {parts.map((p, i) =>
        p.startsWith("**") && p.endsWith("**")
          ? <strong key={i} className="text-foreground">{p.slice(2, -2)}</strong>
          : <span key={i}>{p}</span>
      )}
    </>
  );
}
