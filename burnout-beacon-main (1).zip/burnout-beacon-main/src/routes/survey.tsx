import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { toast } from "sonner";
import { questions, defaultAnswers } from "@/lib/survey-questions";
import { computeScore, type SurveyAnswers, type Answer } from "@/lib/scoring";

export const Route = createFileRoute("/survey")({
  head: () => ({
    meta: [
      { title: "Your check-in — Solace" },
      { name: "description", content: "A short, private check-in to reflect on how school and screens have been feeling lately." },
    ],
  }),
  component: SurveyPage,
});

function SurveyPage() {
  const navigate = useNavigate();
  const [ready, setReady] = useState<null | boolean>(null);
  const [answers, setAnswers] = useState<SurveyAnswers>(defaultAnswers);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) {
        navigate({ to: "/auth", search: { next: "/survey" } });
        return;
      }
      setReady(true);
    });
  }, [navigate]);

  if (!ready) return <div className="mx-auto max-w-2xl px-4 py-24 text-center text-muted-foreground">Preparing your quiet space…</div>;

  function updateLikert(key: keyof SurveyAnswers, value: number) {
    setAnswers((a) => ({ ...a, [key]: value as Answer }));
  }
  function updateHours(value: number) {
    setAnswers((a) => ({ ...a, screenTimeHours: value }));
  }

  async function submit() {
    setBusy(true);
    try {
      const scores = computeScore(answers);
      // Stash ephemerally — never written to a database.
      sessionStorage.setItem("solace:answers", JSON.stringify(answers));
      sessionStorage.setItem("solace:scores", JSON.stringify(scores));
      navigate({ to: "/report" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Couldn't submit.");
      setBusy(false);
    }
  }

  const sections = ["Cognitive", "Emotional", "Physical", "Context"] as const;

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <header className="text-center mb-10">
        <h1 className="font-display text-3xl md:text-4xl">Your check-in</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          Answer with what feels closest to the truth. There are no right or wrong answers —
          and nothing you say here is stored anywhere.
        </p>
      </header>

      <div className="space-y-10">
        {sections.map((section) => (
          <section key={section} className="soft-card p-6">
            <h2 className="font-display text-xl text-primary">{section}</h2>
            <div className="mt-6 space-y-8">
              {questions.filter((q) => q.section === section).map((q) => (
                <div key={q.key}>
                  <Label className="text-sm text-foreground leading-snug">{q.prompt}</Label>
                  {q.kind === "likert" ? (
                    <div className="mt-4">
                      <Slider
                        value={[answers[q.key] as number]}
                        min={1} max={5} step={1}
                        onValueChange={(v) => updateLikert(q.key, v[0])}
                      />
                      <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                        <span>{q.scale[0]}</span>
                        <span className="font-medium text-foreground">{answers[q.key]}</span>
                        <span>{q.scale[1]}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4">
                      <Slider
                        value={[answers.screenTimeHours]}
                        min={0} max={16} step={1}
                        onValueChange={(v) => updateHours(v[0])}
                      />
                      <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                        <span>0h</span>
                        <span className="font-medium text-foreground">{answers.screenTimeHours}h / day</span>
                        <span>16h+</span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>

      <div className="mt-10 flex justify-center">
        <Button size="lg" className="rounded-full" onClick={submit} disabled={busy}>
          {busy ? "Reading your answers…" : "See my reflection"}
        </Button>
      </div>
      <p className="mt-6 text-center text-xs text-muted-foreground">
        Your answers stay in this browser session and are used once to generate your reflection.
      </p>
    </div>
  );
}
