import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/understanding")({
  head: () => ({
    meta: [
      { title: "Why students are quietly burning out — Solace" },
      { name: "description", content: "What academic burnout and digital fatigue really are, why they creep in unnoticed, and how a gentle check-in can help you catch them early." },
      { property: "og:title", content: "Why students are quietly burning out — Solace" },
      { property: "og:description", content: "Plain-language explanations of academic burnout and digital fatigue for students." },
    ],
  }),
  component: Understanding,
});

function Understanding() {
  return (
    <article className="mx-auto max-w-3xl px-4 sm:px-6 py-16">
      <p className="text-sm text-primary font-medium uppercase tracking-wider">Understanding what's going on</p>
      <h1 className="mt-3 font-display text-4xl md:text-5xl leading-tight">
        Have you ever felt like the deadlines never end — and neither does the tiredness?
      </h1>
      <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
        You open your laptop for one assignment and close it three hours later, unsure where the time went and
        somehow more drained than before. That feeling has names. And they matter.
      </p>

      <section className="mt-10 soft-card p-6">
        <h2 className="font-display text-2xl">What Solace is here to do</h2>
        <p className="mt-3 text-muted-foreground leading-relaxed">
          Our system can detect early patterns like lack of sleep, high screen time, low motivation and
          concentration issues before students completely crash academically, through the information
          collected by the questionnaires. It explores your situation through multiple thought perspectives
          — catered specifically to you rather than following a linear, generic path.
        </p>
      </section>

      <section className="mt-10">
        <h2 className="font-display text-3xl">Academic burnout</h2>
        <p className="mt-4 text-muted-foreground leading-relaxed">
          Academic burnout is a prolonged state of academic stress that shows up as overwhelming exhaustion,
          demotivation, detachment from school, and self-doubt. It doesn't happen overnight. It builds
          quietly through relentless coursework, high expectations, and too little rest — until the work you
          used to enjoy starts to feel meaningless, and even small tasks become impossible to start.
        </p>
        <p className="mt-4 text-muted-foreground leading-relaxed">
          Left unnoticed, burnout can spill beyond school: irregular sleep, low mood, dropped routines, and a
          persistent sense that you're falling behind yourself.
        </p>
      </section>

      <section className="mt-10">
        <h2 className="font-display text-3xl">Digital fatigue</h2>
        <p className="mt-4 text-muted-foreground leading-relaxed">
          Digital fatigue is mental exhaustion caused specifically by excessive, meaningless digital
          engagement — hours of virtual classes, assignments, messages, and mindless scrolling without real
          breaks. It creeps in gradually. Its most common signs are headaches, eye strain, difficulty
          focusing, and a low, restless mood after long screen sessions.
        </p>
        <p className="mt-4 text-muted-foreground leading-relaxed">
          The two often intertwine. Late-night screens delay sleep, poor sleep reduces focus, reduced focus
          increases workload stress — and academic burnout gets a running start.
        </p>
      </section>

      <section className="mt-10 rounded-2xl p-6 bg-gradient-to-br from-[color-mix(in_oklab,var(--pastel-pink)_45%,transparent)] to-[color-mix(in_oklab,var(--pastel-blue)_40%,transparent)] border border-border">
        <h2 className="font-display text-2xl">The good news</h2>
        <p className="mt-3 text-muted-foreground leading-relaxed">
          Both burnout and digital fatigue leave early footprints. When you catch them early — sleep quality
          slipping, focus getting shorter, motivation dimming — small, protective changes are enough. Waiting
          until you crash is what makes recovery hard.
        </p>
        <div className="mt-5 flex flex-wrap gap-3">
          <Link to="/survey"><Button className="rounded-full">Take the check-in</Button></Link>
          <Link to="/find-help"><Button variant="secondary" className="rounded-full">Find a professional</Button></Link>
        </div>
      </section>

      <p className="mt-10 text-xs text-muted-foreground">
        Solace is a reflective tool, not a medical service. It cannot diagnose any condition. If any of this
        resonates with you, please speak with a licensed mental health professional.
      </p>
    </article>
  );
}
